import {
  InputText,
  InputTextModule
} from "./chunk-XEECZAVD.js";
import "./chunk-3HGBIGAR.js";
import "./chunk-F7MWMJGV.js";
import "./chunk-HPT665I3.js";
import "./chunk-5E7ZADVT.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
