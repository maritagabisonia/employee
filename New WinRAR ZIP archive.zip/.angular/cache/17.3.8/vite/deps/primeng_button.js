import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-POV67TL6.js";
import "./chunk-ZNX7GV3U.js";
import "./chunk-QERWVE2H.js";
import "./chunk-F7MWMJGV.js";
import "./chunk-HPT665I3.js";
import "./chunk-5E7ZADVT.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
