
export class profession {
    id: number;
    profession: string;


    constructor(    id: number = 0 , profession: string = "" )
    {
        this.id =id;
        this.profession =profession;
    }


}