import { Component } from '@angular/core';
import { FormBuilder, Validators,ReactiveFormsModule,AbstractControl,ValidationErrors   }
  from '@angular/forms';
import { Employee } from '../../model/employee';
import { EmployeeService } from '../../services/employee.service';
import { ButtonModule } from 'primeng/button';
import { Router } from '@angular/router';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule } from 'primeng/dropdown'; 
import { ProfessionsService } from '../../services/professions.service';
import { profession } from '../../model/profession';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';


@Component({
  selector: 'app-employee-form',
  standalone: true,
  imports: [ReactiveFormsModule,
    ButtonModule,
    FloatLabelModule,
    InputTextModule,
    DropdownModule,
    ConfirmDialogModule,
    ToastModule
    ],
  templateUrl: './employee-form.component.html',
  styleUrl: './employee-form.component.css',
  providers: [ConfirmationService, MessageService]
})
export class EmployeeFormComponent {
  employee: Employee = new Employee();
  professions :profession[]= [];


  
  employeeForm = this.fb.group({
    firstName: ['', this.validateFirstName],
    lastName: ['', Validators.required],
    age: [, Validators.required],
    personId: ['', Validators.required],
    professionId: [, Validators.required],
  });
  validateFirstName(control: AbstractControl): ValidationErrors | null {
    return control.value.length < 3 || control.value.length > 7 ? { wrongUserName: { value: control.value } } : null;

  }


  constructor(private confirmationService: ConfirmationService, private messageService: MessageService, private fb: FormBuilder,public EmployeeService:EmployeeService,private router: Router,public professionsService:ProfessionsService) {

  }
  ngOnInit() {
    this.professionsService.getProfessions().subscribe(data => {
      console.log(data);

      this.professionsService.professionsList = data;
      this.professions = this.professionsService.professionsList;
    }
    );

  }

  AddEmployee(){
    console.log(this.employeeForm.value)

    Object.assign(this.employee, this.employeeForm.value)
    console.log(this.employee)
    this.EmployeeService.addEmployee(this.employee).subscribe(res => {
      this.EmployeeService.getEmployees().subscribe(
        data => {
          this.EmployeeService.EmployeeList = data;
          this.router.navigate(['']);
        })
    }
    );
  
  }
    confirm1(event: Event) {
        this.confirmationService.confirm({
            target: event.target as EventTarget,
            message: 'Are you sure that you want to save?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-triangle',
            acceptIcon:"none",
            rejectIcon:"none",
            rejectButtonStyleClass:"p-button-text",
            accept: () => {
                this.messageService.add({ severity: 'info', summary: 'Confirmed', detail: 'You have accepted', life: 3000 });
                setTimeout(() => {
                  this.AddEmployee(); 
                }, 1000); 
            },
            reject: () => {
                this.messageService.add({ severity: 'error', summary: 'Rejected', detail: 'You have rejected', life: 3000 });
            }
        });
    }

    confirm2(event: Event) {
        this.confirmationService.confirm({
            target: event.target as EventTarget,
            message: 'Do you want to delete this record?',
            header: 'Delete Confirmation',
            icon: 'pi pi-info-circle',
            acceptButtonStyleClass:"p-button-danger p-button-text",
            rejectButtonStyleClass:"p-button-text p-button-text",
            acceptIcon:"none",
            rejectIcon:"none",

            accept: () => {
                this.messageService.add({ severity: 'info', summary: 'Confirmed', detail: 'Record deleted' , life: 2000 });
                this.router.navigate(['']);
            },
            reject: () => {
                this.messageService.add({ severity: 'error', summary: 'Rejected', detail: 'You have rejected', life: 2000 });
            }
        });
    }




}
